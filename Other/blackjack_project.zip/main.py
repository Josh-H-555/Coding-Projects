#import libraries
import random
from art import logo

#list of card values
cards = [11, 2, 3, 4, 5, 6, 7, 8, 9, 10, 10, 10, 10]

def deal_card():
  """Returns a random card from the cards list."""
  return random.choice(cards)

def decision(decision_string, a, b):
  """Gets an input from the user, either y or n, checks for validity, then returns true or false."""
  choice = input(f"{decision_string} ({a}/{b}): ")
  while choice.lower() != a and choice.lower() != b:
    choice = input(f"Please enter a valid input. ({a}/{b}): ")
  if choice.lower() == a:
    return True
  else:
    return False

def main():

  new_game = True

  while new_game:

    #Print greeting, ask if they want to play. Check input for errors.
    print(logo + "\n\n")
    play = decision("Would you like to play blackjack?", 'y', 'n')

    #must be declared outside of loop.
    player_cards = []
    player_total = 0

    cpu_cards = []
    cpu_total = 0

    #Variable to check if player is skipping their turn.
    stand = False

    #Game loop
    while play:
      
      #Clear the terminal screen
      print("\033c")

      #Deals new card to player. Checks if it is an ace, and if it would put them over 21. Adds to deck.
      #Only does this if player doesn't choose 'stand'

      if not stand:
        new_player_card = deal_card()
        if (player_total + new_player_card > 21) and new_player_card == 11:
          player_total += 1
          new_player_card = 1
        else:
          player_total += new_player_card
        player_cards.append(new_player_card)
      
      
      #Deals new card to CPU. Checks if it is an ace, and if it would put them over 21. Adds to deck.
      new_cpu_card = deal_card()
      if (cpu_total + new_cpu_card > 21) and new_player_card == 11:
        cpu_total += 1
        new_player_card = 1
      else:
        cpu_total += new_cpu_card
      cpu_cards.append(new_cpu_card)
      
      #Checks if somebody has lost or won, if so, game is over.
      if player_total >= 21:
        play = False
      elif cpu_total >= 21:
        play = False

      print(f"\nYour Cards: {player_cards}\n\nCPU's First Card: {cpu_cards[0]}\n\n")
      
      #Choice for hit or stand.
      if play == True:
        stand = not decision("Hit or stand?", 'h', 's')
    

    #Prints score totals
    print(f"Player: {player_total}\nCPU: {cpu_total}\n")

    #Logic to check who wins. Blackjack has lots of conditions to check for win/lose
    if player_total > 21:
      if cpu_total > 21:
        print("\nIt's a draw!")
      else:
        print("\nCPU wins!")
    
    elif cpu_total > 21:
      print("\nPlayer wins!")
    
    elif player_total > cpu_total:
      print("\nPlayer wins!")
    elif player_total < cpu_total:
      print("\nCPU wins!")
    else:
      print("\nIt's a draw!")

    new_game = decision("Would you like to play another game?", 'y', 'n')


  





main()

